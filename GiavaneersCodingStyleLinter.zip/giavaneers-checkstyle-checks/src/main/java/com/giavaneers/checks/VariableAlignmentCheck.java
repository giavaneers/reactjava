package com.giavaneers.checks;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.puppycrawl.tools.checkstyle.api.*;

public class VariableAlignmentCheck extends AbstractCheck
{

   protected int[]           tokens           = { TokenTypes.VARIABLE_DEF };
   protected List<DetailAST> alignedVariables = new ArrayList<DetailAST>();
   protected int             lastLine         = 0;
	
	@Override
	public int[] getAcceptableTokens() 
	{
		return tokens;
	}

	@Override
	public int[] getDefaultTokens() 
	{
		return tokens;
	}

	@Override
	public int[] getRequiredTokens()
	{
		return tokens;
	}

	@Override
    public void visitToken(DetailAST declaration)
    {
    	if (alignedVariables.isEmpty() || declaration.getLineNo() - 1 == lastLine)
    	{
    		alignedVariables.add(declaration);
    		lastLine = declaration.getLineNo();
    	}
    	else
    	{
    		if (alignedVariables.size() > 1)
    		{
        		checkAligned();
    		}
    		alignedVariables.clear();
    	}
    }
    
    protected void checkAligned() 
    {
    	Map<Integer, Integer> chunkedDeclaration = new HashMap<Integer, Integer>();
		DetailAST chunk = alignedVariables.get(0).getFirstChild();
		
		chunkedDeclaration.put(chunk.getType(), getTrueColumn(chunk));
		
		for (int j = 1; j < alignedVariables.get(0).getChildCount(); j++)
		{
			chunk = chunk.getNextSibling();

         chunkedDeclaration.put(chunk.getType(), getTrueColumn(chunk));
		}
		
    	for (int i = 1; i < alignedVariables.size(); i++)
    	{
    		chunk = alignedVariables.get(i).getFirstChild();
         if (checkOne(chunk, chunkedDeclaration.get(chunk.getType())))
         {
            continue;
         }
    		
    		for (int j = 1; j < alignedVariables.get(i).getChildCount(); j++)
    		{
    			chunk = chunk.getNextSibling();
    			if (checkOne(chunk, chunkedDeclaration.get(chunk.getType())))
            {
               break;
            }
    		}
    	}
    }

    protected boolean checkOne(DetailAST chunk, int columnNo)
    {
       boolean retVal = false;

       if (getTrueColumn(chunk) != columnNo
          && chunk.getType() != TokenTypes.SEMI)
       {
          log(chunk, "variable declaration not aligned", "");
          retVal = true;
       }

       return retVal;
    }

    protected int getTrueColumn(DetailAST chunk)
    {
       int col = chunk.getColumnNo();

       if (chunk.getType() == TokenTypes.TYPE &&
          chunk.getFirstChild().getType() == TokenTypes.ARRAY_DECLARATOR)
       {
          col = chunk.getFirstChild().getFirstChild().getColumnNo();
       }

       return col;
    }
}
