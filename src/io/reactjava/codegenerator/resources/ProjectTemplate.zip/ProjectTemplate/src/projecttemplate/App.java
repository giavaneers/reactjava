/*==============================================================================

name:       App.java

purpose:    HelloWorld App.

history:    Sat May 13, 2018 10:30:00 (Giavaneers - LBM) created

notes:

                  This program was created by Giavaneers
        and is the confidential and proprietary product of Giavaneers Inc.
      Any unauthorized use, reproduction or transfer is strictly prohibited.

                     COPYRIGHT 2018 BY GIAVANEERS, INC.
      (Subject to limited distribution and restricted disclosure only).
                           All rights reserved.


==============================================================================*/
                                       // package --------------------------- //
package projecttemplate;
                                       // imports --------------------------- //
import io.reactjava.client.gwt.react.AppComponentTemplate;
import io.reactjava.client.gwt.react.Properties;

                                       // App ================================//
public class App extends AppComponentTemplate<Properties>
{
                                       // class constants --------------------//
                                       // (none)                              //
                                       // class variables ------------------- //
                                       // (none)                              //
                                       // public instance variables --------- //
                                       // (none)                              //
                                       // protected instance variables -------//
                                       // (none)                              //
                                       // private instance variables -------- //
                                       // (none)                              //
/*------------------------------------------------------------------------------

@name       App - default constructor
                                                                              */
                                                                             /**
            Required default constructor. This implementation is null, but it
            is not required to be.

@return     An instance of App iff successful.

@history    Mon Aug 28, 2018 10:30:00 (Giavaneers - LBM) created

@notes
                                                                              */
//------------------------------------------------------------------------------
public App()
{
}
/*------------------------------------------------------------------------------

@name       App - constructor for specified properties
                                                                              */
                                                                             /**
            Required constructor for specified properties. This implementation
            is essentially null, but it often is not.

@return     An instance of App iff successful.

@history    Mon Aug 28, 2018 10:30:00 (Giavaneers - LBM) created

@notes
                                                                              */
//------------------------------------------------------------------------------
public App(
   Properties props)
{
   super(props);
}
/*------------------------------------------------------------------------------

@name       render - render component
                                                                              */
                                                                             /**
            Render component. This implementation is all markup, with no java
            code included.

@return     void

@history    Mon May 21, 2018 10:30:00 (Giavaneers - LBM) created
            Wed Oct 17, 2018 10:30:00 (Giavaneers - LBM) renamed per suggestion
               by Ethan Elshyeb.

@notes

                                                                              */
//------------------------------------------------------------------------------
public void render()
{
/*--
   <h1 class='hello' style='color:blue;marginTop:30px;fontSize:20px'>
      Hello World!
   </h1>
--*/
};
/*------------------------------------------------------------------------------

@name       renderCSS - get component css
                                                                              */
                                                                             /**
            Get component css. This implementation is elementary, but any css
            can go here.

@return     void

@history    Mon May 21, 2018 10:30:00 (Giavaneers - LBM) created

@notes

                                                                              */
//------------------------------------------------------------------------------
public void renderCSS()
{
/*--
   .hello {
      color: green
   }
--*/
};
}//====================================// end App ============================//
